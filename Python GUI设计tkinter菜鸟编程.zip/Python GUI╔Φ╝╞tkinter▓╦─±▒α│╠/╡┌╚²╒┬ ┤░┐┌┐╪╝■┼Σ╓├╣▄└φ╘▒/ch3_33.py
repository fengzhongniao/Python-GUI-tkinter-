# sticky参数与anchor类似，但是只可以设置N/S/W/E,即上下左右对齐
# 默认是居中对齐
from tkinter import *
root =Tk()
root.title("ch3_31")

lab1 = Label(root,text="明志工专",relief="raised")
lab2 = Label(root,bg="yellow",width=20)
lab3 = Label(root,text="明志科技大学")
lab4 = Label(root,bg="aqua",width=20)
lab1.grid(row=0,column=0,padx=5,pady=5,sticky=N+W)
lab2.grid(row=0,column=1,padx=5,pady=5)
lab3.grid(row=1,column=0,padx=5)
lab4.grid(row=1,column=1,padx=5)
root.mainloop()