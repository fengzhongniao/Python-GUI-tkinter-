# 直接将控件放在容器的方法
# x/y：参数
# 相对位置，按照坐标轴

from tkinter import *
root = Tk()
root.title("ch3-37")

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow",
             width=15)
lab2 = Label(root,text="长庚大学",
             bg="lightgreen",
             width=15)
lab3 = Label(root,text="长庚科技大学",
             width=15,
             bg="lightblue")
lab1.place(x=0,y=0)
lab2.place(x=30,y=50)
lab3.place(x=60,y=100)




root.mainloop()