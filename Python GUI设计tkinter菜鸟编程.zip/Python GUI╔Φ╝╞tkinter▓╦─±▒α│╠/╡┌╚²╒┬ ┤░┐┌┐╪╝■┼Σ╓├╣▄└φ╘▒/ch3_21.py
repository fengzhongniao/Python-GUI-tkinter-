# 从上到下配置标签，体会expand参数与fill参数的应用
from tkinter import *

root = Tk()
root.title("ch3_21")# 窗口标题

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")# 标签背景浅黄色
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")# 标签背景浅绿色
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")# 标签背景浅蓝色
lab1.pack(fill=X)
lab2.pack(fill=BOTH,expand=0)
lab3.pack(fill=X)
root.mainloop()