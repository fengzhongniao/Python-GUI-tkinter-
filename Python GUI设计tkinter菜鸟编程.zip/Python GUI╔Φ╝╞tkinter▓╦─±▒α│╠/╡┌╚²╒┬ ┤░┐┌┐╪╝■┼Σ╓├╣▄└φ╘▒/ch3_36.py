# rowconfigure(0, weight=1)   row 0的控件当窗口改变大小时缩放比例为1
# columnconfigure(1, weight=1)   column 1的控件当窗口改变大小时缩放比例为1
from tkinter import *
root = Tk()
root.title("ch3_36")

root.rowconfigure(1,weight=1)
root.columnconfigure(0,weight=1)

lab1 = Label(root,text="明志工专",relief="raised")
lab1.grid(row=0,column=0,padx=5,pady=5)
lab2 = Label(root,bg="yellow",width=20)
lab2.grid(row=0,column=1,padx=5,pady=5)
lab3 = Label(root,text="明志科技大学")
lab3.grid(row=1,column=0,padx=5,pady=5)
root.mainloop()