# side参数可以垂直或水平配置控件
# 分别取值为 TOP（默认） BOTTOM LEFT TIGHT
from tkinter import *

Window = Tk()
Window.title("ch3_2")
lab1 = Label(Window,text="明志科技大学",bg="lightyellow",width=15)
lab2 = Label(Window,text="长庚大学",bg="lightgreen",width=15)
lab3 = Label(Window,text="长庚科技大学",bg="lightblue",width=15)
lab1.pack(side=BOTTOM)
lab2.pack(side=BOTTOM)
lab3.pack(side=BOTTOM)


Window.mainloop()