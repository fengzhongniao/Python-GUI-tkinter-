# pack的方法
# slaves():传回所有控件对象
# info():传回pack选项的对应值
# forget():隐藏控件
# location(x,y):传回此点是否在单元格，是传回坐标，不是传回(-1,-1)
# size():控件大小
# propagate(boolean):父窗口控件大小由控件决定
from tkinter import *
root = Tk()
root.title("ch3_23")
print("执行前",root.pack_slaves())
lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")# 标签背景浅黄色
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")# 标签背景浅绿色
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")# 标签背景浅蓝色
print("执行后",root.pack_slaves())
root.mainloop()