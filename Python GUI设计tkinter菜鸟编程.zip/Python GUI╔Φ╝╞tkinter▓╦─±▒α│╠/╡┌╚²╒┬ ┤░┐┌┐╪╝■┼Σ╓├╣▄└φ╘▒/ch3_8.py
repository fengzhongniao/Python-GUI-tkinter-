# 左右边界与容器边界是50像素
from tkinter import *

root = Tk()

root.title("ch3_8")

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow",
             width=15)
lab2 = Label(root,text="长庚大学",
             bg="lightgreen",
             width=15)
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue",
             width=15)
lab1.pack(padx=50)
lab2.pack(padx=50,pady=40)
lab3.pack(padx=50)





root.mainloop()