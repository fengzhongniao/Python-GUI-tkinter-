from tkinter import *

root = Tk()
root.title("ch3_22")# 窗口标题

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")# 标签背景浅黄色
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")# 标签背景浅绿色
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")# 标签背景浅蓝色
lab1.pack(side=LEFT,fill=X)
lab2.pack(side=LEFT,fill=BOTH,expand=1)
lab3.pack(side=LEFT,fill=X)
# lab2.forget()
root.mainloop()