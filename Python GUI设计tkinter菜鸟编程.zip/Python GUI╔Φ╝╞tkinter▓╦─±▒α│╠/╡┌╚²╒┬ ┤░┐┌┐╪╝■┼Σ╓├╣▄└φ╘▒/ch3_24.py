# grid方法类似与电子表格
# 参数row column
from tkinter import *
root = Tk()
root.title("ch3_24")
lab1 = Label(root,text="明志科技大学",
             bg="lightyellow",
             width=15)
lab2 =Label(root,text="长庚大学",
            bg="lightgreen",
            width=15)
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue",
             width=15)
lab1.grid(row=0,column=0)
lab2.grid(row=1,column=0)
lab3.grid(row=5,column=8)
root.mainloop()