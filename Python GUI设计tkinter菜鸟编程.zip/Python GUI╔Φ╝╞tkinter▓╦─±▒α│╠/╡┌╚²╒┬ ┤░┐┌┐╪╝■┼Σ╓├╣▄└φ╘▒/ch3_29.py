# grid方法类似与电子表格
# 参数columnspan
from tkinter import *
root = Tk()
root.title("ch3_29")
lab1 = Label(root,text="标签1",relief="raised")
lab2 = Label(root,text="标签2",relief="raised")
lab3 = Label(root,text="标签3",relief="raised")
lab4 = Label(root,text="标签4",relief="raised")
lab5 = Label(root,text="标签5",relief="raised")
lab6 = Label(root,text="标签6",relief="raised")
lab7 = Label(root,text="标签7",relief="raised")
lab8 = Label(root,text="标签8",relief="raised")
lab1.grid(row=0,column=0)
lab2.grid(row=0,column=1,rowspan=2,columnspan=2)
lab4.grid(row=0,column=3)
lab5.grid(row=1,column=0)
lab8.grid(row=1,column=3)
root.mainloop()