#relx and rely 相对于父窗体的位置
# relwidth and relheight 相对于父窗体的大小
# 其值为0.0~1.0
# 就不会出现显示不全的现象
from tkinter import *
root = Tk()
root.title("ch3-37")

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow",
             width=15)
lab2 = Label(root,text="长庚大学",
             bg="lightgreen",
             width=15)
lab3 = Label(root,text="长庚科技大学",
             width=15,
             bg="lightblue")
lab1.place(x=0,y=0,)
lab2.place(x=30,y=50,width=40,height=50)
lab3.place(x=60,y=100)




root.mainloop()