# anchor该参数控制Widget控件在窗口中的位置
from tkinter import *

root = Tk()
root.title("ch3_12")
# root.geometry("300×180")
oklabel = Label(root,text="OK",# 标签内容是OK
                font="Times 20 bold",# Times字形20粗体
                fg="white",bg="blue")# 蓝底白字
oklabel.pack(anchor="sw",side=RIGHT,# 从右开始向S方向设置
             padx=10,pady=10)# x和y轴间距都是10
root.mainloop()