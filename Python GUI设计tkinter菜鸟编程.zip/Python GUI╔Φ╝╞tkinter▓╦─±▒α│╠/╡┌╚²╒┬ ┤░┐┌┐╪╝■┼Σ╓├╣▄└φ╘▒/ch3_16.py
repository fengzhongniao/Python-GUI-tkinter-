# fill参数告诉控件填满所分配容器区间的方式
# fill=x:填满X轴的方向
# fill=y:填满y轴的方向
# fill=BOTH:全部填满
# fill=NONE:保持原来大小
from tkinter import *

root = Tk()
root.title("ch3_16")# 窗口标题

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")# 标签背景浅黄色
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")# 标签背景浅绿色
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")# 标签背景浅蓝色
lab1.pack(side=LEFT)
lab2.pack()
lab3.pack()
root.mainloop()