# 在ch3_8中，在长庚大学标签左右增加10像素间距
from tkinter import *

root = Tk()
root.title("ch3_8")

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow",
             width=15)
lab2 = Label(root,text="长庚大学",
             bg="lightgreen",
             width=15)
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue",
             width=15)
lab1.pack(side=LEFT)
lab2.pack(side=LEFT,padx=10)# 作用主要体现在这里
lab3.pack(side=LEFT)

root.mainloop()