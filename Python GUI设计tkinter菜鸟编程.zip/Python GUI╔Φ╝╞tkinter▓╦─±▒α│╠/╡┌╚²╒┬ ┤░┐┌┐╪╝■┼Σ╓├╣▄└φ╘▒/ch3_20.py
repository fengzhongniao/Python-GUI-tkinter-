# expand 设置的是控件是否填满额外的父容器空间，按照0或1设置
from tkinter import *

root = Tk()
root.title("ch3_20")# 窗口标题

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")# 标签背景浅黄色
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")# 标签背景浅绿色
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")# 标签背景浅蓝色
lab1.pack(side=LEFT,fill=Y)
lab2.pack(fill=X)
lab3.pack(fill=BOTH,expand=1)# 额外空间的参数不一样
root.mainloop()