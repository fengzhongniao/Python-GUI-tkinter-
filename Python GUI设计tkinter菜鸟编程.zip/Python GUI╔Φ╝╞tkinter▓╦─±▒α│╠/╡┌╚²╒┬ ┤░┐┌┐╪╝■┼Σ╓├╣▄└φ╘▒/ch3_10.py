# ipadx参数可以控制标签文字与标签容器的x轴间距
# ipady参数可以控制标签文字与标签容器的y轴间距
from tkinter import *

root = Tk()
root.title("ch3_10")# 窗口标题

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")
lab1.pack()
lab2.pack(ipadx=20)
lab3.pack()

root.mainloop()