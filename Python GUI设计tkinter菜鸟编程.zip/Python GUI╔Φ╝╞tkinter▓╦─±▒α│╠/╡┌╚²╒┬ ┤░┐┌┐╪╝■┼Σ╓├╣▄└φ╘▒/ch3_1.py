# side参数可以垂直或水平配置控件
from tkinter import *

Window = Tk()
Window.title("ch3_1")
lab1 = Label(Window,text="明志科技大学",bg="lightyellow")
lab2 = Label(Window,text="长庚大学",bg="lightgreen")
lab3 = Label(Window,text="长庚科技大学",bg="lightblue")
lab1.pack()
lab2.pack()
lab3.pack()


Window.mainloop()