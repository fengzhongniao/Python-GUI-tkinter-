# padx/pady设置控件边界与容器的距离或者是控件边界之间的距离
# padx/pady代表水平间距和垂直间距
# fill是填满整个轴
from tkinter import *

root = Tk()
root.title("ch3_7")  # 窗口标题

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")# 标签背景是浅黄色
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")# 标签背景是浅绿色
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")# 标签背景是浅蓝色
lab1.pack(fill=X)
lab2.pack(pady=10)
lab3.pack(fill=X)







root.mainloop()