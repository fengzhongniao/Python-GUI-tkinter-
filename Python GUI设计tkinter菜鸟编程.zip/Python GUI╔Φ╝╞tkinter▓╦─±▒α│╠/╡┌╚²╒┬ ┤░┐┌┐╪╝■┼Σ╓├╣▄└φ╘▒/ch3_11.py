# 控制标签文字与容器间距在y轴的距离
from tkinter import *

root = Tk()
root.title("ch3_11")

lab1 = Label(root,text="明志科技大学",
             bg="lightyellow")
lab2 = Label(root,text="长庚大学",
             bg="lightgreen")
lab3 = Label(root,text="长庚科技大学",
             bg="lightblue")
lab1.pack()
lab2.pack(ipadx=10)
lab3.pack(ipady=10)

root.mainloop()