# 列出relief的所有属性
# flat groove raised ridge solid sunken

from tkinter import *

root = Tk()
root.title("ch3_5")

Reliefs = ["flat", "groove", "ridge", "solid", "sunken"]
for relief in Reliefs:
    label = Label(root,text=relief,fg="blue",font="Times 20 bold",relief=relief).pack(side=LEFT,padx=5)# 注意引号的使用，


root.mainloop()