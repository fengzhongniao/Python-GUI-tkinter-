# 列出所有bitmap位图
# error hourglass info questhead question warning gray12 gray25 gray50 gray75

from tkinter import *

root = Tk()
root.title("ch3_6")

Bitmaps = ["error", "hourglass", "info", "questhead",
           "question", "warning", "gray12", "gray25", "gray50", "gray75"]
for bitmaps in Bitmaps:
    label = Label(root,text="relief",fg="blue",font="Times 20 bold",bitmap=bitmaps,
                  compound="left").pack(side=LEFT,padx=5)# 注意引号的使用，


root.mainloop()