'''
使用事件绑定方式让单击Click me 按钮后可以列出“Button clicked"字符串
绑定事件的语法
    widget.bin(event,handle)
'''
from tkinter import *
# Python复选框事件处理程序
def pythonClicked():
    if varPython.get():
        lab.config(text="Select Python")
    else:
        lab.config(text="Unselect Python")
# Java复选框事件处理程序
def javaClicked():
    if varJava.get():
        lab.config(text="Select Java")
    else:
        lab.config(text="Unselect Java")
# button按钮事件处理程序
def buttonClicked(self,event):# 设置参数
    lab.config(text="Button clicked")
    print("Clicke at :",event.x,event.y)
# 主窗口建立
root = Tk()
# 主窗口命名
root.title('ch11_2')
# 主窗口设置大小为300x180
root.geometry("300x180")
# 建立按钮，设置显示文字为Clik me 。
btn = Button(root,text="Clik me",command=buttonClicked)
# 按钮设置的位置
btn.pack(anchor=W)
# 单击Click me绑定buttonClicked方法
btn.bind("<Button-1>",buttonClicked)
# 建立变量
varPython = BooleanVar()
# 建立Python的复选框
cbnPython = Checkbutton(root,text="Python",variable=varPython,
                        command=pythonClicked)
cbnPython.pack(anchor=W)
# 设置变量，针对Java
varJava = BooleanVar()
cbnJava = Checkbutton(root,text="Java",variable=varJava,# 当前选择的值
                        command=javaClicked)
cbnJava.pack(anchor = W)
lab = Label(root,bg="yellow",fg="blue",
            height=2,width=12,
            font="Times 16 bold")
lab.pack()
root.mainloop()