'''
Protocols 通信协议
窗口管理程序与应用程序之间的通信协议

'''
# 单击通信协议内容窗口右上角的x按钮可以关闭窗口，它的名称是
# WM_DELETE_WINDOW,这个程序会修改此协议，改为单击此按钮
# 后增加Messagebox，询问”结束或取消“,若是单击‘确定’按钮才会结束此程序
from tkinter import *
from tkinter import messagebox
def callback():
    res = messagebox.askokcancel("OKCANCEL","结束或取消")
    if res== True:
        root.destroy()
    else:
        return
root = Tk()
root.title('ch11_9')
root.geometry('300x180')
root.protocol("WM_DELETE_WINDOW",callback)

root.mainloop()