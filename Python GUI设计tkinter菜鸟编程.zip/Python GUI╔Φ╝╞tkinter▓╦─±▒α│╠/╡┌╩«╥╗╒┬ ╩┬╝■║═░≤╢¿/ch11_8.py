'''
一个事件绑定多个事件处理程序
新加的事件处理程序需要在bind()方法内增加参数add="+"
'''
# 下面是一个单击功能按钮动作，会有两件事处理程序做出相应
from tkinter import *
# Button按钮事件处理程序1
def btnClicked1():
    print("Command event handler,I like tkinter")

# Button按钮事件处理程序2
def btnClicked2(event):
    print("Bind event handler, I like tkinter")

root = Tk()
root.title('ch11_8')
root.geometry('300x180')

btn = Button(root,text='tkinter',
             command=btnClicked1)
btn.pack(anchor=W,padx=10,pady=10)
btn.bind('<Button-1>',btnClicked2,add='+')# 添加事件处理程序
root.mainloop()