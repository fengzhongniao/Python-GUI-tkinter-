'''
移动鼠标时可以在窗口右下方看到鼠标目前的位置
'''
from tkinter import *
def mouseMotion(event):# Nouse移动事件
    x=event.x
    y= event.y
    textvar =  "Mouse locate - x:{}, y:{}".format(x,y)
    var.set(textvar)


root = Tk()
root.title("ch11_3_1")# 窗口标题
root.geometry("300x180")# 窗口大小

x,y = 0,0# 建立x,y的坐标
var = StringVar()
text = "Mouse locate - x:{}, y:{}".format(x,y)
var.set(text)

lab = Label(root,textvariable=var)# 建立标签
lab.pack(anchor=S,side=RIGHT,padx=10,pady=10)
root.bind("<Button-1>",mouseMotion)# 添加事件处理程序


root.mainloop()