'''
这是一个测试键盘绑定的程序，在执行时会出现窗口，若是按Esc键，
将出现对话框询问是否离开，单击按钮是就退出，单击否就不退出
'''
from tkinter import *
from tkinter import messagebox

def leave(event):
    ret = messagebox.askyesno("ch11_5","是否离开？")
    if ret == True:
        root.destroy()
    else:
        return
root =Tk()
root.title("ch11_5")

root.bind("<Escape>",leave)
lab = Label(root,text="测试Esc键",
            bg="yellow",fg="blue",
            height=4,width=15,
            font="Times 12 bold")
lab.pack(padx=30,pady=30)
root.mainloop()
