'''
打印所按的键
'''
from tkinter import *
def key(event):
    print("按了"+repr(event.char)+"键")#处理键盘按a~z键事件

root = Tk()
root.title("ch11_6")
root.bind("<Key>",key)
root.mainloop()