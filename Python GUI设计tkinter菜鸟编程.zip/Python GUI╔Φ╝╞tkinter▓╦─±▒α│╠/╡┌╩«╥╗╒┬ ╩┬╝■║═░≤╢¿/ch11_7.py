'''
鼠标与键盘绑定Frame对象的应用
'''
from tkinter import *
def key(event):
    print("按了"+repr(event.char)+"键")

def cordXY(event):
    frame.focus_set()
    print("鼠标坐标：",event.x,event.y)
root = Tk()
root.title("ch11_7")
frame = Frame(root,width=100,height=100)
frame.bind("<Key>",key)# 键盘事件绑定
frame.bind("<Button-1>",cordXY)# 鼠标事件绑定
frame.pack()
root.mainloop()