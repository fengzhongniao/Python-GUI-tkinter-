'''
当鼠标进入到按钮时，标签会显示
当鼠标离开按钮时，标签会显示
'''
from tkinter import *
# 设置处理程序
def enter(event):
    x.set("鼠标进入Exit功能按钮")
def leave(event):
    x.set("鼠标离开Exit功能按钮")
root = Tk()
root.title("ch11_4")
root.geometry("300x180")
# 设置按钮
btn = Button(root,text="Exit",command=root.destroy)
btn.pack(pady=30)
btn.bind("<Enter>",enter)
btn.bind("<Leave>",leave)
# 设置标签
x= StringVar()
lab = Label(root,textvariable=x,bg="yellow",fg="blue",
            height = 4,width=15,
            font="Times 12 bold")
lab.pack(pady=30)
root.mainloop()