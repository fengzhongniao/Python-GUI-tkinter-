'''
取消绑定
obj.unbind("<xxx>")
这是一个tkinter按钮程序，在tkinter按钮下方有复选框bind/
'''
'''
这是一个tkinter按钮程序，在tkinter按钮下方有复选框bind/unbind
如果勾选这个复选框，相当于有绑定，在单击tkinter按钮时Python Shell会列出字符串“I Like tkinter"，
如果没有选择这个复选框，相当于没有绑定，在单击时，没有任何反应
'''
from tkinter import *


def buttonClicked(event):
    print('I like tkinter')

# 所传递的对象onoff是btn对象
def toggle(onoff):
    if var.get() == True:
        onoff.bind('<Button-1>',buttonClicked)
    else:
        onoff.unbind("<Button-1>")

root = Tk()
root.title('ch11_7_1')
root.geometry("300x180")
# 创建按钮
btn = Button(root,text="tkinter")
btn.pack(anchor=W,padx=10,pady=10)
# 创建复选框
var = BooleanVar()
cbtn = Checkbutton(root,text='bind/unbind',variable=var,
                   command=lambda :toggle(btn))
cbtn.pack(anchor=W,padx=10)
root.mainloop()