'''
鼠标事件的基本应用，这个程序在执行时会建立300x180大小的窗口，
当单击鼠标右键时，在Python shell窗口中会列出单击事件的坐标
'''
from tkinter import *
# callback函数设置
def callback(event):# 事件处理程序
    print("Clicked at",event.x,event.y)# 打印坐标

root = Tk()
root.title('ch11_3')
fram = Frame(root,width=300,height=180)
fram.bind("<Button-1>",callback)
fram.pack()
root.mainloop()

