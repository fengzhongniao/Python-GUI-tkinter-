'''
当单击功能按钮或是选择复选框时，窗口下方会做出所执行的动作，
所利用的就是Widget控件构造方法内的command参数
'''
from tkinter import *
# Python复选框事件处理程序
def pythonClicked():
    if varPython.get():
        lab.config(text="Select Python")
    else:
        lab.config(text="Unselect Python")
# Java复选框事件处理程序
def javaClicked():
    if varJava.get():
        lab.config(text="Select Java")
    else:
        lab.config(text="Unselect Java")
# button按钮事件处理程序
def buttonClicked():
    lab.config(text="Button clicked")
# 主窗口建立
root = Tk()
# 主窗口命名
root.title('ch11_1')
# 主窗口设置大小为300x180
root.geometry("300x180")
# 建立按钮，设置显示文字为Clik me 。
btn = Button(root,text="Clik me",command=buttonClicked)
btn.pack(anchor=W)
# 设置变量，针对Python
varPython = BooleanVar()
cbnPython = Checkbutton(root,text="Python",variable=varPython,
                        command=pythonClicked)
cbnPython.pack(anchor=W)
# 设置变量，针对Java
varJava = BooleanVar()
cbnJava = Checkbutton(root,text="Java",variable=varJava,# 当前选择的值
                        command=javaClicked)
cbnJava.pack(anchor = W)
lab = Label(root,bg="yellow",fg="blue",
            height=2,width=12,
            font="Times 16 bold")
lab.pack()
root.mainloop()