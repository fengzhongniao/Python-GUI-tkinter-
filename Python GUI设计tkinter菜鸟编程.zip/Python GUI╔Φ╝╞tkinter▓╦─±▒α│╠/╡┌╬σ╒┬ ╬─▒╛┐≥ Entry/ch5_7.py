"""
使用delete(first,last=None)方法删除Entry内的从第一first字符到last-1字符，
如果删除整个字符可以使用delete(0,END)

"""
from tkinter import *
def printInfo():
    print("Account:%s\nPassword:%s"%(accountE.get(),pwdE.get()))
    accountE.delete(0,END)# 删除账号内容
    pwdE.delete(0,END)# 删除内容

root = Tk()
root.title("ch5_3")

msg = "欢迎进入Silicon Stone Education系统"
sseGif = PhotoImage(file="sun.gif")
logo = Label(root,image=sseGif,text=msg,compound=BOTTOM)
accountL = Label(root,text="Account")
accountL.grid(row=1,column=0)
pwdL = Label(root,text="Password")
pwdL.grid(row=2,column=0)
logo.grid(row=0,column=0,columnspan=3,pady=10,padx=10)
accountE = Entry(root)
pwdE = Entry(root,show="*")
accountE.insert(0,"Kevin")
pwdE.insert(0,"pwd")
accountE.grid(row=1,column=1)
pwdE.grid(row=2,column=1,pady=10)

loginbtn = Button(root,text="Login",command=printInfo)
loginbtn.grid(row=3,column=0,sticky=W,pady=5,padx=5)
quitbtn = Button(root,text="Quit",command=root.quit)
quitbtn.grid(row=3,column=1,sticky=W,pady=5,padx=5)

root.mainloop()