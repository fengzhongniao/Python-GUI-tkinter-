"""
Entry有一个get()方法，可以利用这个方法获得目前Entry的字符串内容。
Widget控件有一个常用方法quit，执行此方法时Python Shell窗口的程序将结束，
但是此窗口应用程序继续运行。
Login按钮和Quit按钮并没有对齐上方的标签和文本框，我们在grid()方法内增加sticky参数
"""
from tkinter import *
def printInfo():
    print("Account:%s\nPassword:%s"%(accountE.get(),pwdE.get()))

root = Tk()
root.title("ch5_3")

msg = "欢迎进入Silicon Stone Education系统"
sseGif = PhotoImage(file="sun.gif")
logo = Label(root,image=sseGif,text=msg,compound=BOTTOM)
accountL = Label(root,text="Account")
accountL.grid(row=1,column=0)
pwdL = Label(root,text="Password")
pwdL.grid(row=2,column=0)
logo.grid(row=0,column=0,columnspan=3,pady=10,padx=10)
accountE = Entry(root)
pwdE = Entry(root,show="*")
accountE.grid(row=1,column=1)
pwdE.grid(row=2,column=1,pady=10)

loginbtn = Button(root,text="Login",command=printInfo)
loginbtn.grid(row=3,column=0,sticky=W,pady=5,padx=5)
quitbtn = Button(root,text="Quit",command=root.quit)
quitbtn.grid(row=3,column=1,sticky=W,pady=5,padx=5)

root.mainloop()