# 使用show参数隐藏输入的字符
# 当输入字符时隐藏起来并用*表示
from tkinter import *
root = Tk()
root.title("ch5_2")
accountL = Label(root,text="Account")
accountL.grid(row=0,column=0)
pwdL = Label(root,text="Password")
pwdL.grid(row=1,column=0)

accountE = Entry(root)
pwdE = Entry(root,show="*")# 隐藏字符，用*号表示
accountE.grid(row=0,column=1)
pwdE.grid(row=1,column=1)


root.mainloop()