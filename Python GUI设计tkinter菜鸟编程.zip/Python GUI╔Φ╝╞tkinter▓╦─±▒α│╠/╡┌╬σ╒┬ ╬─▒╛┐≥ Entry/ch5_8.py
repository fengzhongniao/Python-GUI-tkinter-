"""
该函数可以直接传回此数学表达式的计算结果
result = eval(expression)
"""
from tkinter import *

expression = input("请输入数学表达式:")
print("结果是:",eval(expression))