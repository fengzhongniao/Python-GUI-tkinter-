'''
窗口中一般会有菜单设计，菜单是一种下拉式窗体，
在这种窗体中可以设计菜单列表建立菜单的方法是Menu(),
它的语法格式为：Menu(父对象,options,...)
'''
# 建立最上层的菜单列表，单击“Hello!”会出现“欢迎使用菜单”的对话框，单击“Exit”则程序结束
from tkinter import *
from tkinter import messagebox

def hello():
    messagebox.showinfo("Hello","欢迎使用菜单")

root = Tk()
root.title("ch16_1")
root.geometry("300x180")

# 建立上层菜单
menubar = Menu(root)
menubar.add_command(label="Hello!",command=hello)
menubar.add_command(label="Exit!",command=root.destroy)
root.config(menu=menubar)     # 显示菜单对象
root.mainloop()