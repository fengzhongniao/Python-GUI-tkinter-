'''
建立菜单时所使用的概念如下：
menubar = Menu(root)
filemenu = Menu(menubar)
menu.add_cascade(label="File",menu=filemenu)
所谓建立子菜单就是在File菜单内另外建立一个子菜单。
'''
# 在File菜单内建立Find子菜单，这个子菜单内有Find Next和Find Pre命令
from tkinter import *
from tkinter import messagebox
def findNext():
    messagebox.showinfo("Find Next","查找下一个")
def findPre():
    messagebox.showinfo("Find Pre","查找下一个")

root = Tk()
root.title("ch16_8")
root.geometry("300x180")

menubar = Menu(root)
# 建立菜单类别对象，并将菜单类别命名为File
filemenu = Menu(menubar)
menubar.add_cascade(label="File",menu=filemenu,underline=0)
# 在File菜单内建立菜单列表
# 首先在File菜单内建立find子菜单对象
findmenu = Menu(filemenu,tearoff=False)
findmenu.add_command(label = "Finid Next",command=findNext)
findmenu.add_command(label="Find Pre",command=findPre)
filemenu.add_cascade(label="Find",menu=findmenu)
# 下面增加分隔线和建立Exit子菜单
filemenu.add_separator()
filemenu.add_command(label="Exit!",command=root.destroy,underline=0)

root.config(menu=menubar)
root.mainloop()