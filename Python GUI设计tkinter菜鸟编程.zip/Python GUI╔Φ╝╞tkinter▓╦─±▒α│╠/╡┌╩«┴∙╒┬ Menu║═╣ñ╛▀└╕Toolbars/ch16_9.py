'''
建立弹出式菜单
'''
from tkinter import *
from tkinter import messagebox
def minimizeIcon():
    root.iconify()
def showPopupMenu(event):
    popupmeun.post(event.x_root,event.y_root)

root = Tk()
root.title("ch16_9")
root.geometry("300x180")

popupmeun = Menu(root,tearoff=False)
# 在弹出菜单内建立两个指令列表
popupmeun.add_command(label="Minimize",command=minimizeIcon)
popupmeun.add_command(label="Exit",command=root.destroy)
# 单击鼠标右键绑定显示弹出菜单
root.bind("<Button-3>",showPopupMenu)
root.mainloop()