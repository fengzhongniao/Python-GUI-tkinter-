'''
菜单列表间加上分隔线
'''
# add_separator()
from tkinter import *
from tkinter import messagebox
def newFile():
    messagebox.showinfo("New file","新建文档")
def openFile():
    messagebox.showinfo("New File","打开文档")
def saveFile():
    messagebox.showinfo("New File","保持文档")
def saveAsFile():
    messagebox.showinfo("New File","另存为")

root=Tk()
root.title("ch16_4")
root.geometry("300x180")

menbar = Menu(root)
filemenu = Menu(menbar)
menbar.add_cascade(label="File",menu=filemenu)
filemenu.add_command(label="New File",command=newFile)
filemenu.add_command(label="Open File",command=openFile)
filemenu.add_separator()
filemenu.add_command(label="Save",command=saveFile)
filemenu.add_command(label="Save As",command=saveAsFile)
filemenu.add_command(label="Exit!",command=root.destroy)
root.config(menu=menbar)
root.mainloop()