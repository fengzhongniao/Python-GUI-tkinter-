'''
建立多个菜单的应用
'''
# 增加Help菜单
from tkinter import *
from tkinter import messagebox
def newFile():
    messagebox.showinfo("New file","新建文档")
def openFile():
    messagebox.showinfo("New File","打开文档")
def saveFile():
    messagebox.showinfo("New File","保持文档")
def saveAsFile():
    messagebox.showinfo("New File","另存为")
def aboutMe():
    messagebox.showinfo("New File","洪锦魁著")

root=Tk()
root.title("ch16_5")
root.geometry("300x180")

menubar = Menu(root)

filemenu = Menu(menubar)
menubar.add_cascade(label="File",menu=filemenu)
filemenu.add_command(label="New File",command=newFile)
filemenu.add_command(label="Open File",command=openFile)
filemenu.add_separator()
filemenu.add_command(label="Save",command=saveFile)
filemenu.add_command(label="Save As",command=saveAsFile)
filemenu.add_command(label="Exit!",command=root.destroy)

helpmenu = Menu(menubar)
menubar.add_cascade(label="Help",menu=helpmenu)
helpmenu.add_command(label="About me",command=aboutMe)
root.config(menu=menubar)
root.mainloop()