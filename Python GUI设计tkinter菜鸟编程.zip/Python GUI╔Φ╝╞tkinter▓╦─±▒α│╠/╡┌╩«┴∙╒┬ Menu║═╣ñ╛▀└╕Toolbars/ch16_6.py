'''
建立多个菜单的应用
'''
# 增加Help菜单
# #Alt快捷键
# 是某个菜单类别或是列表指令的英文字符串内为单一字母增加下划线，
# 然后可以使用Alt键先启动此功能，当菜单显示下划线字母时，可以
# 直接按指定字母键启动该功能，
#  add_cascade(...,underline=n)
#  add_command(...,underline=n)
from tkinter import *
from tkinter import messagebox
def newFile():
    messagebox.showinfo("New file","新建文档")
def openFile():
    messagebox.showinfo("New File","打开文档")
def saveFile():
    messagebox.showinfo("New File","保持文档")
def saveAsFile():
    messagebox.showinfo("New File","另存为")
def aboutMe():
    messagebox.showinfo("New File","洪锦魁著")

root=Tk()
root.title("ch16_6")
root.geometry("300x180")

menubar = Menu(root)

filemenu = Menu(menubar)
menubar.add_cascade(label="File",menu=filemenu,underline=0)
filemenu.add_command(label="New File",command=newFile,underline=0)
filemenu.add_command(label="Open File",command=openFile,underline=0)
filemenu.add_separator()
filemenu.add_command(label="Save",command=saveFile,underline=0)
filemenu.add_command(label="Save As",command=saveAsFile,underline=5)
filemenu.add_command(label="Exit!",command=root.destroy,underline=0)

helpmenu = Menu(menubar)
menubar.add_cascade(label="Help",menu=helpmenu,underline=0)
helpmenu.add_command(label="About me",command=aboutMe,underline=1)
root.config(menu=menubar)
root.mainloop()