from tkinter import *
from tkinter import messagebox

def myMesg():
    messagebox.showinfo("My Message Box","Python Tkinter早安")

window = Tk()
window.title("ch10_4")
window.geometry("300x160")

Button(window,text="Good Morning",command=myMesg).pack()

window.mainloop()