# Message的基本应用
from tkinter import *
root = Tk()
root.title("ch10_1")

myText = '2016年12月，我一个人订了机票和船票，开始我的南极旅行'
msg = Message(root,bg='yellow',text=myText,
              font="times 12 italic")
msg.pack(padx=10,pady=10)

root.mainloop()