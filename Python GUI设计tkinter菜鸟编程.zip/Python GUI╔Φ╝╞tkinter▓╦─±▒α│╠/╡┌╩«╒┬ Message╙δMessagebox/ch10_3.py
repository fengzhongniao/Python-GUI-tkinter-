# 使用字符串变量处理text参数
# 将背景设为黄色
from tkinter import *
root = Tk()
root.title("ch10_3")

var = StringVar()
msg = Message(root,textvariable=var,relief=RAISED)
var.set('2016年12月，我一个人订了机票和船票，开始我的南极旅行')
msg.config(bg="yellow")
msg.pack(padx=10,pady=10)
root.mainloop()