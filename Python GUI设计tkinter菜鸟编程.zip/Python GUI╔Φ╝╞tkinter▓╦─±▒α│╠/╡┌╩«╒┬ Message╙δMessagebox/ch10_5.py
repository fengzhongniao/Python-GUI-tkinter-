from tkinter import *
from tkinter import messagebox

def myMsg1():
    ret = messagebox.askretrycancel("Test1","安装失败，再来一次？")
    print(
        "安装失败",ret
    )

def myMsg2():
    ret = messagebox.askretrycancel("Test2", "安装失败，再来一次？")
    print("安装成功", ret)
root = Tk()
root.title("ch10_5")

Button(root,text="安装失败",command=myMsg1).pack()
Button(root,text="编辑完成",command=myMsg2()).pack()

root.mainloop()
