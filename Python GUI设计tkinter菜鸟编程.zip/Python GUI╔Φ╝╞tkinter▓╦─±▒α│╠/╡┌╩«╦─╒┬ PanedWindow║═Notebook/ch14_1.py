'''
PanedWindow：面板
可以在此容器内建立任意数量的子控件
语法格式:PanedWindow(父对象,options,...)
'''
# 插入子控件add()
# 在PanedWindow对象内插入两个标签子对象，读者可以从缩放窗口了解标签子对象分割此PanedWindow
from tkinter import *
# 创建容器对象
pw = PanedWindow(orient=VERTICAL)
pw.pack(fill=BOTH,expand=True)

top = Label(pw,text="Top Pane")
pw.add(top)

bottom = Label(pw,text="Bottom Pane")
pw.add(bottom)
pw.mainloop()