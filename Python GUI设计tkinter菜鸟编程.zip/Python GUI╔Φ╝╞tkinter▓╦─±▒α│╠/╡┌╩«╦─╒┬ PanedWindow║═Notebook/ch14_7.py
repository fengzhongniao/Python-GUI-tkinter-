'''
建立NoteBook的框架
'''
from tkinter import *
from tkinter.ttk import *
from tkinter import messagebox
def msg():
    messagebox.showinfo("Notebook","欢迎使用Notebook")
root = Tk()
root.title("ch14_7")
root.geometry("300x180")

notebook = Notebook(root)

frame1 = Frame()
frame2 = Frame()

label = Label(frame1,text="Python")
label.pack(padx=10,pady=10)
btn = Button(frame2,text="Help",command=msg)
btn.pack(padx=10,pady=10)

notebook.add(frame1,text="页次1")
notebook.add(frame2,text="页次2")
notebook.pack(padx=10,pady=10,fill=BOTH,expand=TRUE)
root.mainloop()