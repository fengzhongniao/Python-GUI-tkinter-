'''
建立LabelFrame当作子对象
'''
# 建立三个LabelFrame对象当作PanedWindow的子对象，然后水平排列
# add(子对象，options)weight参数代表更改窗口宽度时，每个Pane更改的比例
from tkinter import *
from tkinter.ttk import *
root = Tk()
root.title("ch14_3")

pw = PanedWindow(orient=HORIZONTAL)

leftframe = LabelFrame(pw,text="Left Pane",width=120,height=150)
pw.add(leftframe,weight=1)
middleframe = LabelFrame(pw,text="Middle Pane",width=120)
pw.add(middleframe,weight=1)
rightframe = LabelFrame(pw,text="Right Pane",width=120)
pw.add(rightframe,weight=1)

pw.pack(fill=BOTH,expand=True,padx=10,pady=10)

root.mainloop()