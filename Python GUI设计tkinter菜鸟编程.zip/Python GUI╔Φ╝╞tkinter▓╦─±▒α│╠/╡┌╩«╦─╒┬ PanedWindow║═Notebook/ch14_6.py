'''
建立NoteBook的框架
'''
from tkinter import *
from tkinter.ttk import *

root = Tk()
root.title("ch14_6")
root.geometry("300x180")

notebook = Notebook(root)

frame1 = Frame()
frame2 = Frame()

notebook.add(frame1,text="选项卡1")
notebook.add(frame2,text="选项卡2")
notebook.pack(padx=10,pady=10,fill=BOTH,expand=True)

root.mainloop()