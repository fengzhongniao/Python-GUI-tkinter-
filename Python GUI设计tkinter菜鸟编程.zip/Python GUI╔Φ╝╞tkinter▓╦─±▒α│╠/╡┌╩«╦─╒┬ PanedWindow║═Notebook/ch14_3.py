'''
建立LabelFrame当作子对象
'''
# 建立三个LabelFrame对象当作PanedWindow的子对象，然后水平排列
from tkinter import *
root = Tk()
root.title("ch14_2")

pw = PanedWindow(orient=HORIZONTAL)

leftframe = LabelFrame(pw,text="Left Pane",width=120,height=150)
pw.add(leftframe)
middleframe = LabelFrame(pw,text="Middle Pane",width=120)
pw.add(middleframe)
rightframe = LabelFrame(pw,text="Right Pane",width=120)
pw.add(rightframe)

pw.pack(fill=BOTH,expand=True,padx=10,pady=10)

root.mainloop()