"""
扩充ch6_3，同时在Entry控件下方建立Label控件，当在Entry中有输入时，
同时在下方的Label控件中显示
"""
from tkinter import *

# 设置函数
def callback(*args):
    xL.set(xE.get())
    print("data changed:",xE.get())

root = Tk()
root.title("ch6_4")


# 设置按钮
xE = StringVar()
entry = Entry(root,textvariable=xE)
entry.pack(pady=5,padx=10)
xE.trace("w",callback)

# 设置同步标签
xL = StringVar()
label = Label(root,textvariable=xL)
xL.set("同步显示")
label.pack(pady=5,padx=10)

root.mainloop()