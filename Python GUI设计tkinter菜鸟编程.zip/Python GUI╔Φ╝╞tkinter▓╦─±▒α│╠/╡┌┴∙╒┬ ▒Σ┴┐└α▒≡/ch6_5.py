"""
追踪trace()使用模式r
设置当内容被读取时，执行追踪并执行特定函数
"""
from tkinter import *

# 设置函数
def callbackW(*args):
    xL.set(xE.get())

def callbackR(*args):
    print("Warning:数据被读取！")

def hit():
    print("读取数据：",xE.get())

root = Tk()
root.title("ch6_5")

# 设置按钮
xE = StringVar()
entry = Entry(root,textvariable=xE)
entry.pack(pady=5,padx=10)
xE.trace("w",callbackW)# 若是有更改执行callbackW
xE.trace("r",callbackR)# 若是有被读取执行callbackR

# 设置同步标签
xL = StringVar()# Label的变量内容
label = Label(root,textvariable=xL)
xL.set("同步显示")
label.pack(pady=5,padx=10)

btn = Button(root,text="读取",command=hit)# 创建"读取"按钮
btn.pack(pady=5)

root.mainloop()