"""
追踪trace()使用模式W
"""
from tkinter import *

def callback(*args):
    print("data changed:",xE.get())#获取每次输入的内容


root = Tk()
root.title("ch6_3")

xE = StringVar()# 创建变量
entry = Entry(root,textvariable=xE)# 建立文本框
entry.pack(pady=200,padx=100)
xE.trace("w",callback)# 若是有更改执行callback

root.mainloop()