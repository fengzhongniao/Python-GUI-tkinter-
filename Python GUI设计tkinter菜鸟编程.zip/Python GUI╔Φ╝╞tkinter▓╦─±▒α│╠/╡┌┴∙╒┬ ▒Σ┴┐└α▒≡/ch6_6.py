"""
trace()方法调用的callback方法参数
def callback(*args):
其实传递三个参数，分别时tk变量名称、index索引、mode模式
"""
from tkinter import *

# 设置函数
def callbackW(name,index,mode):
    xL.set(xE.get())
    print("name = %r, index = %r,mode = %r"%(name,index,mode))

root = Tk()
root.title("ch6_6")

# 设置按钮
xE = StringVar()
entry = Entry(root,textvariable=xE)
entry.pack(pady=5,padx=10)
xE.trace("w",callbackW)# 若是有更改执行callbackW

# 设置同步标签
xL = StringVar()# Label的变量内容
label = Label(root,textvariable=xL)
xL.set("同步显示")
label.pack(pady=5,padx=10)

root.mainloop()