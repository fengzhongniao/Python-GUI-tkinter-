"""
可以考虑变量
使用get()变量获取变量内容，使用set()变量设置内容
"""
from tkinter import *
def btn_hit():
    # global msg_on
    if x.get() == "":
        msg_on = True
        x.set("I like tkinter")
    else:
        # msg_on = False
        x.set("")
root = Tk()
root.title("ch6_1")
msg_on = False
x = StringVar()

label = Label(root,textvariable=x,
              fg="blue",bg="lightyellow",
              font="Verdana 16 bold",
              width=25,height=2)
label.pack()
btn = Button(root,text="Click Me",command=btn_hit)
btn.pack()
root.mainloop()