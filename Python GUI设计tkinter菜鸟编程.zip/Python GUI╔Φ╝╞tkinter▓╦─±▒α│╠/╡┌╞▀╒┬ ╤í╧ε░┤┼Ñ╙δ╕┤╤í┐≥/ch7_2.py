"""
使用字符串设置Radiobutton方法内的value参数值，
重新设计7_1.py，读者会发现printSelection()函数
"""
from tkinter import *
def printSelection():
    label.config(text="你是"+var.get())

root = Tk()
root.title("ch7_2")# 窗口标题
# 选项按钮绑定的变量
# 默认选项是男生
var = StringVar()
var.set(0)
label = Label(root,text="这是默认值，尚未选择",bg="lightyellow",width=30)
label.pack()
# 男生选项
rbman = Radiobutton(root,text="男生",
                    variable=var,value="男生",
                    command=printSelection)
rbman.pack()
# 女生选项
rbwoman = Radiobutton(root,text="女生",
                      variable=var,value="女生",
                      command=printSelection)
rbwoman.pack()
root.mainloop()