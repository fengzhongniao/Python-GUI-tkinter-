# 建立含图像的选项按钮
from  tkinter import *
def printselection():
    label.config(text="你选的是"+var.get())

root = Tk()
root.title("ch7_5")

imgStar = PhotoImage(file="star.gif")
imgMoon = PhotoImage(file="moon.gif")
imgSun = PhotoImage(file="sun.gif")

var = IntVar()
var.set("星星")

label = Label(root,text="这是最喜欢的城市",
              fg="blue",bg="lightyellow",width=30)
label.pack()

rbStar = Radiobutton(root,image=imgStar,
                     variable=var,value="星星",
                     command=printselection)
rbStar.pack()
rbMoon = Radiobutton(root,image=imgMoon,
                     variable=var,value="月亮",
                     command=printselection)
rbMoon.pack()
rbSun = Radiobutton(root,image=imgSun,
                     variable=var,value="太阳",
                     command=printselection)
rbSun.pack()

root.mainloop()