"""
这是一个简单的选项按钮的选项，程序刚执行时默认选项是“男”，
此时窗口上方显示尚未选择，然后可以选择男生或者女生，选择完成后，就显示结果
"""
from tkinter import *
def printSelection():
    num = var.get()
    if num ==1:
        label.config(text="你是男生")
    else:
        label.config(text="你是女生")

root = Tk()
root.title("ch7_1")# 窗口标题

var = IntVar()
var.set(0)
# 标签
label = Label(root,text="这是预设，尚未选择",bg="lightyellow",width=30)
label.pack()
#男生和女生选项
rbman = Radiobutton(root,text="男生",
                    variable=var,value=1,
                    command=printSelection)
rbwoman = Radiobutton(root,text="女生",
                    variable=var,value=2,
                    command=printSelection)
"""
variable:设置或取得目前选取的单选按钮，它的值类型通常是IntVar或StringVar
value:选项按钮的值，可以区分所选取的选项按钮.
"""
rbman.pack()
rbwoman.pack()

root.mainloop()