"""
tkinter 中也提供盒子选项按钮的概念，可以在Radiobutton方法内使用indicatoron参数,将它设为0
"""
from  tkinter import *
def printselection():
    print(cities[var.get()])

root = Tk()
root.title("ch7_4")
cities = {0:'东京',1:'纽约',2:'巴黎',3:'伦敦',4:'香港'}

var = IntVar()
var.set(0)
label = Label(root,text="这是最喜欢的城市",
              fg="blue",bg="lightyellow",width=30).pack()
for val, city in cities.items():
    Radiobutton(root,
                text=city,
                indicatoron=0,
                width=30,
                variable=var,value=val,
                command=printselection).pack()

root.mainloop()