"""
将字典应用在选项按钮上
"""
from tkinter import *

def printSelction():
    print(cities[var.get()])
root = Tk()
root.title("ch7_3")
cities = {0:'东京',1:'纽约',2:'巴黎',3:'伦敦',4:'香港'}
var = IntVar()
var.set(9)
label = Label(root,text="选择最喜欢的城市",
              fg="blue",bg="lightyellow",width=30).pack()
for val,city in cities.items():
    Radiobutton(root,
                text=city,
                variable=var,value=val,
                command=printSelction).pack()
root.mainloop()