'''
模拟下载的Progressbar设计，假设下载总量是10000B，每次读取数据数量（下载量）是500B
'''
from tkinter import *
from tkinter.ttk import *

def load():# 启动Prograssbar
    pb["value"]=0# Prograssbar初始值
    pb["maximum"]=maxbytes# Prograssbar最大值
    loading()
def loading():# 仿真下载数据
    global bytes
    bytes += 500# 模拟每次下载500B
    pb["value"]=bytes# 设置指针
    if bytes < maxbytes:
        pb.after(50,loading)# 经过0.05s继续执行loading

root = Tk()
root.title("ch15_3")
bytes = 0
maxbytes = 10000

pb = Progressbar(root,length=200,mode="determinate",orient=HORIZONTAL)
pb.pack(padx=10,pady=10)
pb["value"]=0

btn = Button(root,text="Load",command=load)
btn.pack(pady=10)
root.mainloop()