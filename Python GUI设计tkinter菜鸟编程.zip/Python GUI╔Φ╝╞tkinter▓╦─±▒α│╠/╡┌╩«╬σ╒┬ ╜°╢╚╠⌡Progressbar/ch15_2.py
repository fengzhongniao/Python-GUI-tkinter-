'''
如果想要设置动画效果的Progressbar，可以在每次更新Progressbar对象的value值时调用update()方法
'''
import time
from tkinter import *
from tkinter.ttk import *
import time

def running():
    for i in range(100):
        pb["value"]=i+1
        root.update()
        time.sleep(0.05)

root =Tk()
root.title("ch15_2")

pb = Progressbar(root,orient=HORIZONTAL,length = 200,mode="determinate")
pb.pack(pady=10,padx=10)

pb["maximum"]=100
pb["value"]=0

btn = Button(root,text="Running",command=running)
btn.pack(pady=10)

root.mainloop()