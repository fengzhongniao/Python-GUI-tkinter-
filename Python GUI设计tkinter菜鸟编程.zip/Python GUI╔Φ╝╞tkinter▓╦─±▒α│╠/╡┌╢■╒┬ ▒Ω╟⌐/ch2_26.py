# Separator在适当的位置增加分隔线
# 水平：HORIZONTAL,垂直:VERTICAL
from  tkinter import *
from tkinter.ttk import Separator

root = Tk()
root.title("ch2_26")

myTitle = "一个人的极镜旅行"
myContent = "2016年"

label = Label(root,text=myTitle,font="Helvetic 20 bold")
label.pack(padx=10,pady=10)

sep = Separator(root,orient=HORIZONTAL)
sep.pack(fill=X,padx=5)

label1 = Label(root,text=myContent)
label1.pack(padx=10,pady=10)#


root.mainloop()
