# 标签中同时有文字和图片的应用
from tkinter import *

root = Tk()
root.title("ch2_21")

sseText = """SSE全名时Silicon Stone Education，这家公司在美国，这是国际专业证照公司，产品多元与丰富.是世界五百强企业，其创始人，具有很传奇的色彩"""
see_gif = PhotoImage(file="html.gif")
label = Label(root,text=sseText,image=see_gif,bg="lightyellow",justify=LEFT,compound="left")
label.pack()





root.mainloop()