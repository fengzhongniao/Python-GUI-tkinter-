# 让字符串在标签右下角输出
from tkinter import *
root = Tk()
root.title("ch2_4")
label = Label(root,text="I like tkinter",fg="red",bg="yellow",height=3
              ,width=15,anchor="se")
label.pack()
root.mainloop()