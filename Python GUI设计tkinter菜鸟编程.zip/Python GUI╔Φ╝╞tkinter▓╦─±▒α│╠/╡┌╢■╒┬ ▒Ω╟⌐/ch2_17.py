# relief控制边框的样式
# flat groove raised ridge solid sunken
from tkinter import *
root = Tk()
root.title("ch2_17")
label = Label(root,bg="yellow",
              height=300,width=150,
              text="我的天空",fg="red",bitmap="hourglass",
              compound="top",
              relief="solid")
label.pack()
root.mainloop()