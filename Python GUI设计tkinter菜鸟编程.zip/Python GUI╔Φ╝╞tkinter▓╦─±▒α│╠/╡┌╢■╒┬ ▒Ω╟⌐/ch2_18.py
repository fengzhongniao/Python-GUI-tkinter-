# 标签文字与标签区间之间的距离，左右间距为5，标签上下间距为10
from tkinter import *
root = Tk()
root.title("ch2_18")
label = Label(root,bg="yellow",
              height=300,width=150,
              text="我的天空",fg="red",bitmap="hourglass",
              compound="top",
              padx=5,pady=10)
label.pack()
root.mainloop()