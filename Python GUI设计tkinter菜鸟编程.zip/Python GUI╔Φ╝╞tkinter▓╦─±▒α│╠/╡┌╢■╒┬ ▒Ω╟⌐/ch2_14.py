# 图片和文字共存时，图像在左边
# 相对位置：left right top bottom center
from tkinter import *
root = Tk()
root.title("ch2_14")
label = Label(root,bg="yellow",
              height=300,width=150,
              text="我的天空",fg="red",bitmap="hourglass",
              compound="top")
label.pack()
root.mainloop()