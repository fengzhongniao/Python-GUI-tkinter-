# 设置标签宽度15，高度3，背景色黄色，前景色蓝色
from tkinter import *
root = Tk()
root.title("ch2_4")
label = Label(root,text="I like tkinter",fg="red",bg="yellow",height=3
              ,width=15)
label.pack()
root.mainloop()
