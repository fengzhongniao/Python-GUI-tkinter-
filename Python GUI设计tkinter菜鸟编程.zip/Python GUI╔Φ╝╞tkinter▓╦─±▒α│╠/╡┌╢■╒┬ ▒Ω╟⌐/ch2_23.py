# 未来在程序执行时，如果想要建立或者是更改属性可以使用config（）方法
from tkinter import *

counter = 0
def run_counter(digit):
    def counting():
        global counter
        counter += 1
        digit.config(text=str(counter))
        digit.after(1000,counting)# 隔一秒后调用counting
    counting()# 持续调用
root = Tk()
root.title("ch2_23")

digit=Label(root,bg="yellow",fg="blue",
            height=3,width=10,
            font="Helvetic 20 bold")
digit.pack()
run_counter(digit)

root.mainloop()