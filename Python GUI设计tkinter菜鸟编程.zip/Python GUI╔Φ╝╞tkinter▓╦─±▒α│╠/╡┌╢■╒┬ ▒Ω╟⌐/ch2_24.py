# Cursors的应用
from tkinter import *

root = Tk()
root.title("ch2_24")

label = Label(root,text="raised",relief="raised",bg="lightyellow",
              padx=5,pady=10,
              cursor="heart")
label.pack()

root.mainloop()