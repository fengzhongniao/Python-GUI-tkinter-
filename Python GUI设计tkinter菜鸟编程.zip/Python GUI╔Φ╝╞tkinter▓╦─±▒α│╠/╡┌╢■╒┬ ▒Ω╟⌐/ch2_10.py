# 使用默认方式执行多行输出，并观察最后一行是居中对齐输出
from tkinter import *
root = Tk()
root.title("ch2_9")
label = Label(root,text="I like tkinter I like tkinter I like tkinter",
              fg="red",bg="yellow",
              height=300,width=150,
              font="Helvetic 20 bold",
              wraplength=80,
              justify="left")
label.pack()
root.mainloop()