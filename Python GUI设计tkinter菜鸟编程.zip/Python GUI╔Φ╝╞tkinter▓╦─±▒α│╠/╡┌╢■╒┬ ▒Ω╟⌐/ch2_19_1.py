from tkinter import *
from PIL import Image, ImageTk

root = Tk()
root.title("ch2_19_1")
# root.geometry(680, 400)

image = Image.open("22级李建华.jpg")
yellowstone = ImageTk.PhotoImage(image)
label = Label(root, image=yellowstone)
label.pack()

root.mainloop()