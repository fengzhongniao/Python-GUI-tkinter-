# 在标签位置显示hourglass位图
# error hourglass info questhead question
# warning gray12 gray25 gray50 gray75
from tkinter import *
root = Tk()
root.title("ch2_13")
label = Label(root,bg="yellow",
              height=300,width=150,bitmap="hourglass")
label.pack()
root.mainloop()