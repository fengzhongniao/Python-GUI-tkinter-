# 使用anchor选项重新设计ch2_4.py，让字符串从标签区间的左上角位置开始输出
from tkinter import *
root = Tk()
root.title("ch2_4")
label = Label(root,text="I like tkinter",fg="red",bg="yellow",height=3
              ,width=15,anchor="nw")
label.pack()
root.mainloop()
