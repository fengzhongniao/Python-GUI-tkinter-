# 让标签中的文字达到40像素宽度后自动换行
from tkinter import *
root = Tk()
root.title("ch2_4")
label = Label(root,text="I like tkinter",fg="red",bg="yellow",height=3
              ,width=15,anchor="nw",wraplength=40)
label.pack()
root.mainloop()