# 使用Helvetic字形，大小是20，粗体显示
# font：设置字形，有以下参数
# 字形family:Helvetica、Times
# 字号size:bold、normal
# slant:italic、roman
# underline:True、False
# overstrike:True、False
from tkinter import *
root = Tk()
root.title("ch2_8")
# label = Label(root,text="I like tkinter",
#               fg="red",bg="yellow",
#               height=3,width=15,
#               font="Helvetic 20 bold")
label = Label(root,text="I like tkinter",
              fg="red",bg="yellow",
              height=3,width=15,
              font=("Helvetic", 20,"bold"))
label.pack()
root.mainloop()