# ch2_2.py
# 使用Label().pack()方式设计
from tkinter import *
root = Tk()
root.title("ch2_2")
label = Label(root,text="I like tkinter").pack()
print(type(label))
root.mainloop()