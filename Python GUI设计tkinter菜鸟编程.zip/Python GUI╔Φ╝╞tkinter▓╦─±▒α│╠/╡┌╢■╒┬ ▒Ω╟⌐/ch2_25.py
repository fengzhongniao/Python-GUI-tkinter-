# key()方法可以用列表返回这个Widget所有的参数
from tkinter import *

root = Tk()
root.title("ch2_25")

label = Label(root,text="I like tkinter")
label.pack()
print(label.keys())


root.mainloop()