# 标签的应用，建立一个标签，内容是"I like tkinter"，同时在Python Shell窗口中列出Label的数据类型
from tkinter import Tk, Label

from tkinter import *
root = Tk()
root.title("ch2_1")
# root.wm_geometry(300200)
label = Label(root, text="I like tkinter")
label.pack()
print(type(label))#返回Label数据类型
root.mainloop()

