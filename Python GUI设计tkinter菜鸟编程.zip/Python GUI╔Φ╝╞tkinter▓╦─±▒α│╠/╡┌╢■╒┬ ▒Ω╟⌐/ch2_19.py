# 使用PhotoImage()方法建立图像对象
# PhotoImage(file="xxx.gif")
from tkinter import *

root = Tk()
root.title("ch2_19")

html_gif = PhotoImage(file="html.gif")
label = Label(root,image=html_gif)
label.pack()

root.mainloop()
# 如果需要导入jpg格式的图片，则需要安装pillow，导入其中的Image、ImageTk模块
# 应用Image.open()函数打开图片，建立图片对象
