# 设置文字前景色为蓝色，背景色是黄色
from tkinter import *
root = Tk()
root.title("ch2_3")
label = Label(root,text="I like tkinter",fg="red",bg = "yellow")
label.pack()
root.mainloop()
