# 单击功能按钮显示字符串"I love Python",底色是浅黄色，字符串颜色是蓝色
from tkinter import *
def msgShow():
     label["text"]="I love you"# 设置标签内容
     label["bg"]="lightyellow"# 设置标签内容
     label["fg"]="blue"# 设置标签内容
root = Tk()
root.title("ch4_1")
label = Label(root)
button = Button(root,text="打印消息",command=msgShow)
label.pack()
button.pack()

root.mainloop()