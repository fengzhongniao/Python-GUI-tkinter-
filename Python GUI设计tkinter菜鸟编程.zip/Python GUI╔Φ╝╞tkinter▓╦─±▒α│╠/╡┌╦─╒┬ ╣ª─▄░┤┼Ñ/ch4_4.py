# 添加结束按钮，单击结束按钮就结束程序
from tkinter import *

counter = 0
# 实现循环调用
def run_counter(digit):
    def counting():
        global counter
        counter +=1
        digit.config(text=str(counter))
        digit.after(1000,counting)
    counting()

root = Tk()
root.title("ch4_4")
# 设置标签，并调用函数
digit = Label(root,bg="yellow",fg="blue",
              height=3,width=10,
              font="Helvetic 20 bold")
digit.pack()
run_counter(digit)
# 设置按钮功能以及布局
btn1 = Button(root,text="结束",width=15,command=root.destroy)
btn1.pack(pady=10)
root.mainloop()