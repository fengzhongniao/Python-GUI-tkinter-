# 在窗口右下角有三个按钮，单击Yellow按钮可以将窗口背景设置为黄色，单击Blue按钮可以将窗口背景设置为蓝色，单击
# Exit按钮可以结束程序
from tkinter import *

def yellow():# 设置背景颜色是黄色
    root.config(bg="yellow")
def blue():# 设置窗口背景是蓝色
    root.config(bg="blue")

root = Tk()
root.title("ch4_5")
#依次设置新建按钮三个按钮
exitbtn = Button(root,text="Exit",command=root.destroy)
bluebtn = Button(root,text="Blue",command=blue)
yellowbtn = Button(root,text="yellow",command=yellow)
# 设置布局
exitbtn.pack(anchor=S,side=RIGHT,padx=5,pady=5)
bluebtn.pack(anchor=S,side=RIGHT,padx=5,pady=5)
yellowbtn.pack(anchor=S,side=RIGHT,padx=5,pady=6)


root.mainloop()