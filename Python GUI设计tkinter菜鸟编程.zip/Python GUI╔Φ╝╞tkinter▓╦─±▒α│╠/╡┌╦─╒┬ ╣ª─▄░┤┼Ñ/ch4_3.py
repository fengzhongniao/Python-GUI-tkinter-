# 单击结束按钮，可以关闭窗口
# 在按钮属性command中调用root.destroy或者root.quit
# 其中root.destry关闭root窗口
# 其中root.quit不会关闭root窗口,在Python Shell中起作用
from tkinter import *

def msgShow():
    label.config(text="I love you",bg="lightyellow",fg="blue")

root = Tk()
root.title("ch4_3")
label = Label(root)
btn1 = Button(root,text="打印消息",width=15,command=msgShow)
btn2 = Button(root,text="结束",width=15,command=root.destroy)
label.pack()
btn1.pack(side=LEFT)
btn2.pack(side=LEFT)
root.mainloop()