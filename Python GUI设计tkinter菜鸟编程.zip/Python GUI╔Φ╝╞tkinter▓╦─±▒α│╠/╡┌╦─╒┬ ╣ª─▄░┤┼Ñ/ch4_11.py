# 设计鼠标光标在功能按钮上的形状
from tkinter import *
def msgShow():
    label.config(text="I LOVE PYTHON",bg="lightyellow",fg="blue")
root = Tk()
root.title("ch4_11")
label = Label(root)

sunGif = PhotoImage(file="sun.gif")
btn = Button(root,image=sunGif,command=msgShow,
             cursor="star")# star形状
label.pack()
btn.pack()

root.mainloop()