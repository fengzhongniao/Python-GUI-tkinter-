# 使用config()方法一次设置所有控件属性

from tkinter import *

def msgShow():
    label.config(text="I love Python",bg="lightyellow",fg="blue") # 采用config()一次设置所有属性
root = Tk()
root.title("ch4_2")# 窗口标题
label = Label(root)# 标签内容
btn = Button(root,text="打印消息",command=msgShow)
label.pack()
btn.pack()

root.mainloop()