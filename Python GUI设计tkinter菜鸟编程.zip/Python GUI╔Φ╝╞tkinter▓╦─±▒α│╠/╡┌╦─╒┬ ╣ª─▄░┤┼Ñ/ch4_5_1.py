# 使用lambda表达式
# yellow和blue按钮执行相同的工作，但是所传的颜色参数不一样
from tkinter import *
def bcolor(bgColor):# 设置背景颜色
    root.config(bg=bgColor)
root = Tk()
root.title("ch4_5_1")
#依次设置新建按钮三个按钮
exitbtn = Button(root,text="Exit",command=root.destroy)
bluebtn = Button(root,text="Blue",command=lambda:bcolor("blue"))
yellowbtn = Button(root,text="yellow",command=lambda:bcolor("yellow"))
# 设置布局
exitbtn.pack(anchor=S,side=RIGHT,padx=5,pady=5)
bluebtn.pack(anchor=S,side=RIGHT,padx=5,pady=5)
yellowbtn.pack(anchor=S,side=RIGHT,padx=5,pady=6)


root.mainloop()