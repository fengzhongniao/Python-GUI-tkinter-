# 使用sun.gif图像取代“打印消息”按钮
from tkinter import *
def msgShow():
    label.config(text="I love python",bg="lightyellow",fg="blue")

root = Tk()
root.title("ch4_6")
label = Label(root)
sunGif = PhotoImage(file="sun.gif")
btn = Button(root,image=sunGif,command=msgShow)
label.pack()
btn.pack()

root.mainloop()