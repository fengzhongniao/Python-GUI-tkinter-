# 以序列存储Spinbox的数值数据
# 使用get()方法取得目前Spinbox
from tkinter import *

def printInfo():
    print(sp.get())
root = Tk()
root.title("ch9_7")
root.geometry("300x100")
sp =Spinbox(root,values=(10,38,170,101),command=printInfo)
sp.pack(pady=20)

root.mainloop()