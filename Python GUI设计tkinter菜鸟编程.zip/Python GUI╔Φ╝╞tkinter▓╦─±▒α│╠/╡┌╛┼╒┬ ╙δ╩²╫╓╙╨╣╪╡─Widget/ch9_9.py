# 非数值数据
from tkinter import *

def printInfo():
    print(sp.get())
root = Tk()
root.title("ch9_7")
root.geometry("300x100")
sp =Spinbox(root,values=('新加坡','上海','东京'),command=printInfo)
sp.pack(pady=20)

root.mainloop()