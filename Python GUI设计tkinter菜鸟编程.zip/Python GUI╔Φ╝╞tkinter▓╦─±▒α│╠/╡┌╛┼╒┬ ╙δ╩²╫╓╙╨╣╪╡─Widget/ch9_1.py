# 一个产生水平尺度条与垂直尺度条的应用
from tkinter import *
window = Tk()
window.title("ch9_1")

slider1 = Scale(window,from_=0,to=10).pack()
slider2 = Scale(window,from_=0,to=10,
                length=300,orient=HORIZONTAL).pack()
window.mainloop()