# 设置Scale()构造方法中的多个参数
from tkinter import *

root = Tk()
root.title("ch9_2")

slider = Scale(root,
               from_=0,# 起点值
               to=10,# 终点值
               troughcolor="yellow",# 槽的颜色
               width=10,# 槽的高度
               #tickinterval=2,# 刻度
               label="My Scale",# Scale标签
               length=300,#Scale 长度
               orient=HORIZONTAL)# 水平
slider.pack()
root.mainloop()