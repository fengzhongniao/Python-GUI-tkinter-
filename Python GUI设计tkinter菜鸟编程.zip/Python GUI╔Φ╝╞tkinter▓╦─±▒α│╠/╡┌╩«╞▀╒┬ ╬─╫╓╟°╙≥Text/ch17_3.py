'''
插入文字insert()
insert(index,string)
'''
from tkinter import *

root = Tk()
root.title("ch17_3")

text = Text(root,height=3,width=30)
text.pack()
str = """
hdioahfiuaofbioaufiroufbiaeruofbreui ioaerughiwerbf weoifnaoif foiweafbaoifhduifoberiwof awdbhaskfbuiewweurfb"""
text.insert(END,str)


root.mainloop()