'''
插入文字insert()
insert(index,string)
添加Scrollbar设计
'''

from tkinter import *

root = Tk()
root.title("ch17_4")
yscrollbar = Scrollbar(root)
text = Text(root,height=3,width=30)
text.pack()
yscrollbar.pack(side=RIGHT,fill=Y)
yscrollbar.config(command=text.yview)
text.config(yscrollcommand=yscrollbar.set)



str = """
hdioahfiuaofbioaufiroufbiaeruofbreui ioaerughiwerbf weoifnaoif foiweafbaoifhduifoberiwof awdbhaskfbuiewweurfb"""
text.insert(END,str)


root.mainloop()