from tkinter import *

root = Tk()
root.title("ch17_1")

text = Text(root,height=2,width=30)
text.pack()

root.mainloop()