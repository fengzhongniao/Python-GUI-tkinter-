'''
虚拟绑定应用与多选
当选择多项时，这些被选的项目将被打印出来
'''
from tkinter import *

def itemsSelected(event):         # 打印所选结果
    obj = event.widget            # 取得事件的对象
    indexs = obj.curselection()   # 取得索引
    for index in indexs:          # 将元组内容列出
        print(obj.get(index))
    print("--------------")

fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]

root = Tk()
root.title("ch12_18")
root.geometry("300x180")

var = StringVar()
lab = Label(root,text="",textvariable=var)
lab.pack(pady=5)

lb = Listbox(root,selectmode=EXTENDED)
for fruit in fruits:
    lb.insert(END,fruit)
lb.bind("<<ListboxSelect>>",itemsSelected)
lb.pack(pady=5)

root.mainloop()

