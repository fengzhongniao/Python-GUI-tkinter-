# 列出列表框中的项目数量
# 目前我们选择的索引位置都是END,ACTIVE,表示在目前选项前面加入一个项目
# size()：返回项目数量
# selection_set()：默认选取特定索引项
# delete()方法内设置一个参数，表示删除这个索引项
# 传回指定索引项 get(),
# 也可以选择一个区间，所有值将会以一个元组的方式进行返回
# 传回所选项目的索引curselection()
from tkinter import *

def callback():
    indexs = lb.curselection()
    for index in indexs:
        print(lb.get(index))


root = Tk()
root.title('ch12_14')
root.geometry('300x180')

fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]
lb = Listbox(root,selectmode=EXTENDED)
lb.pack()
for s in fruits:
    lb.insert(END,s)
btn = Button(root,text="Print",command=callback)
btn.pack()
# print("items数字：",lb.size())
# lb.select_set(1)
# lb.delete(3)
# print(lb.get(2))
root.mainloop()
