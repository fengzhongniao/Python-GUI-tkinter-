'''
拖拽项目
'''
from tkinter import *
def getIndex(event):
    lb.insert = lb.nearest(event.y)
def dragJob(event):
    newIndex = lb.nearest(event.y)
    if newIndex <lb.index:
        x = lb.get(newIndex)
        lb.delete(newIndex)
        lb.insert(newIndex+1,x)
        lb.index = newIndex
    elif newIndex > lb.index:
        x = lb.get(newIndex)
        lb.delete(newIndex)
        lb.insert(newIndex-1,x)
        lb.index = newIndex

fruits = ["Banana","Watermelon","Pineapple",
          "Orange","Grapes","Mango"]

root = Tk()
root.title("ch12_21")

lb = Listbox(root)
for fruit in fruits:
    lb.insert(END,fruit)
    lb.insert(END,fruit)
    lb.bind("<Button-1>",getIndex)
    lb.bind("B1-Motion",dragJob)
lb.pack(padx=10,pady=5)

# btn = Button(root,text="排序",command=itemsSorted)
# btn.pack(side=LEFT,padx=10,pady=5)
#
# var = BooleanVar()
# cb = Checkbutton(root,text="从大到小排列",variable=var)
# cb.pack(side=LEFT)
root.mainloop()