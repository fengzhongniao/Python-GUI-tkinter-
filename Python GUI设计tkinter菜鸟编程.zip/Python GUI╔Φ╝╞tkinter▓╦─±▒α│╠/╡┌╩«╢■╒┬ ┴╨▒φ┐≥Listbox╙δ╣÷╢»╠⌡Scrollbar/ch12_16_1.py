'''
当Listbox执行选取操作时会产生<<ListboxSelect>>虚拟事件，
可以执行处理程序

'''
# 当选取Listbox中的项目时。可以在上方列出所选项目
# 修改处理程序
from tkinter import *

# 建立处理程序
def itemChange(event):
    index = lb.curselection()
    var.set(lb.get(index))
# def itemSelected(event):# 列出所选单一项目
#     obj = event.widget# 取得事件的对象
#     index = obj.curselection()# 取得索引
#     var.set(obj.get(index))# 设置标签内容
fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]
# 建立父窗口
root = Tk()
root.title('ch12_16_1')
root.geometry('300x180')

var = StringVar()
lab = Label(root,text="",textvariable=var)
lab.pack()
# 建立项目
lb = Listbox(root)
for fruit in fruits:
    lb.insert(END,fruit)
    lb.bind("<<ListboxSelect>>",itemChange)
lb.pack()
root.mainloop()