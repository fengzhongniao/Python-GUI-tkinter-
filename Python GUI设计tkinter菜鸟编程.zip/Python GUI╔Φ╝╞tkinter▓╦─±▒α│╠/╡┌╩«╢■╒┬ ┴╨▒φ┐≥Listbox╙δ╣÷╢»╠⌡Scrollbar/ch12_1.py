'''
建立列表框1，然后使用高度5建立列表框2
'''
from tkinter import *
root = Tk()
root.title('ch12_1')
root.geometry('300x180')
# 建立listbox 1
lb1 = Listbox(root)
lb1.pack(side=LEFT,padx=5,pady=10)
# 建立listbox 2
lb2 = Listbox(root,height=5,relief='raised')
lb2.pack(anchor=N,side=LEFT,padx=5,pady=10)

root.mainloop()