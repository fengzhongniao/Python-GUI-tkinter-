# 列出列表框中的项目数量
# 目前我们选择的索引位置都是END,ACTIVE,表示在目前选项前面加入一个项目
# size()：返回项目数量
from tkinter import *

root = Tk()
root.title('ch12_7')
root.geometry('300x180')

fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]
lb = Listbox(root,selectmode=EXTENDED)
lb.pack()
for s in fruits:
    lb.insert(END,s)
print("items数字：",lb.size())
root.mainloop()
