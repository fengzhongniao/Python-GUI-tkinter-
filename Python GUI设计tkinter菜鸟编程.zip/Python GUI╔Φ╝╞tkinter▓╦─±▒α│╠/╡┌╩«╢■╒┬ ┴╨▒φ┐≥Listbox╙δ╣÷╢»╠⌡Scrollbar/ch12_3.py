# 将在ch12_3的基础上，采用循环的方法添加项目
from tkinter import *

root = Tk()
root.title('ch12_3')
root.geometry('300x180')

fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]
lb = Listbox(root)
lb.pack()
for s in fruits:
    lb.insert(END,s)
root.mainloop()
