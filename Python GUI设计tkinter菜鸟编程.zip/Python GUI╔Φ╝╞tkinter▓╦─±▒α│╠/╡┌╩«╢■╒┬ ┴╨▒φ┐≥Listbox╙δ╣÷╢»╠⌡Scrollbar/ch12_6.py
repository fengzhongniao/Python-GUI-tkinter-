# 目前我们选择的索引位置都是END,ACTIVE,表示在目前选项前面加入一个项目
from tkinter import *

root = Tk()
root.title('ch12_6')
root.geometry('300x180')

fruits = ["Banana","Watermelon","Pineapple"]
lb = Listbox(root,selectmode=EXTENDED)
lb.pack()
for s in fruits:
    lb.insert(END,s)
lb.insert(ACTIVE,"Orange","Grapes","Mango")
root.mainloop()
