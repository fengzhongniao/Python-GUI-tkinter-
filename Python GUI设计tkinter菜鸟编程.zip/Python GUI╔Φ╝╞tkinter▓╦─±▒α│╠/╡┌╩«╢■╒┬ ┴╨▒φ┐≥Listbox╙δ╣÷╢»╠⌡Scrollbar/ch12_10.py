# 列出列表框中的项目数量
# 目前我们选择的索引位置都是END,ACTIVE,表示在目前选项前面加入一个项目
# size()：返回项目数量
# selection_set()：默认选取特定索引项
# delete()方法内设置一个参数，表示删除这个索引项
from tkinter import *

root = Tk()
root.title('ch12_10')
root.geometry('300x180')

fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]
lb = Listbox(root,selectmode=EXTENDED)
lb.pack()
for s in fruits:
    lb.insert(END,s)
print("items数字：",lb.size())
lb.select_set(1)
lb.delete(3)
root.mainloop()
