# 在使用Listbox()构造方法中增加selectmode = MULTIPLE,实现用户多选个项目
from tkinter import *

root = Tk()
root.title('ch12_4')
root.geometry('300x180')

fruits = ["Banana","Watermelon","Pineapple","Orange","Grapes","Mango"]
lb = Listbox(root,selectmode=MULTIPLE)
lb.pack()
for s in fruits:
    lb.insert(END,s)
root.mainloop()
