'''
使用insert()方法为列表框建立项目
格式: insert(index,elements)
'''
# 建立列表框，同时为这个列表框建立Banana、Watermelon、Pineapple三个项目
from tkinter import *

root = Tk()
root.title('ch12_2')
root.geometry('300x180')

lb = Listbox(root)
lb.pack()
lb.insert(END,"Banana")
lb.insert(END,"Wtermelon")
lb.insert(END,"Pineapple")

root.mainloop()
