"""
获得选项内容
"""
from tkinter import *

def printSelection():
    print("The selection is:",var.get())
root = Tk()
root.title("ch13_5")
root.geometry("300x180")

omTuple = ("Python","Java","C")# 建立元组
var = StringVar(root)
var.set(omTuple[0])# 建立默认选项
optionmenu = OptionMenu(root,var,*omTuple)# 注意值的表示
optionmenu.pack()

btn = Button(root,text="Print",command=printSelection)
btn.pack(pady=10,anchor=S,side=BOTTOM)

root.mainloop()