'''
下拉式列表
语法格式：OptionMenu(父对象, option,*value)
*value是一系列下拉列表
'''
# 下拉列表的简单实例
from tkinter import *
root = Tk()
root.title("ch13_1")
root.geometry("300x180")

var = StringVar(root)
optionmenu = OptionMenu(root,var,"Python","Java","C")
optionmenu.pack()

root.mainloop()