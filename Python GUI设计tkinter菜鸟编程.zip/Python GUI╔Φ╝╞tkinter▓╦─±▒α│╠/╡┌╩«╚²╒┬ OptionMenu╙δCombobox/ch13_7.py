"""
组合框：下拉列表和Entry的组合
Combobox(父对象,options)
选项的内容：textvariable:可以设置Combox的变量值
          value:Combobox的选项内容，内容以元组的形式存在
"""
# 建立Combobox
from tkinter import *
from tkinter.ttk import *

root = Tk()
root.title("ch13_7")
root.geometry("300x180")

var = StringVar()
cb = Combobox(root,textvariable=var)# 创建Combobox
cb["value"]=("Python","Java","C","C#")# 设置选项内容
cb.pack(pady=10)
root.mainloop()