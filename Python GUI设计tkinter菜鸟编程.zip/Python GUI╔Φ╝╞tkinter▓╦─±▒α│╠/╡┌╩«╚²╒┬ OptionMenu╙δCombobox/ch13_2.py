'''
使用元组建立列表项目
'''
from tkinter import *
root = Tk()
root.title("ch13_2")
root.geometry("300x180")

omTuple = ("Python","Java","C")# 建立元组
var = StringVar(root)
optionmenu = OptionMenu(root,var,*omTuple)# 注意值的表示
optionmenu.pack()

root.mainloop()