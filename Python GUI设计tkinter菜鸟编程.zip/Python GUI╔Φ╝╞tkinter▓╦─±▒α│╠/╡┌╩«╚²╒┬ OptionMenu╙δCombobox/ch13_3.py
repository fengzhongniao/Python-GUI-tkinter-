"""
建立默认选项set()
"""
from tkinter import *
root = Tk()
root.title("ch13_3")
root.geometry("300x180")

omTuple = ("Python","Java","C")# 建立元组
var = StringVar(root)
var.set("Python")# 建立默认选项
optionmenu = OptionMenu(root,var,*omTuple)# 注意值的表示
optionmenu.pack()

root.mainloop()