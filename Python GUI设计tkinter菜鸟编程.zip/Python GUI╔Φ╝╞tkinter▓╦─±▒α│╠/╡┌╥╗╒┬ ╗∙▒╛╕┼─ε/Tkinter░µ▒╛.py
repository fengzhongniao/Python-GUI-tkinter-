# GUI:图形用户接口
# 了解自己使用Tkinter使用的版本
import tkinter
print(tkinter.TkVersion)
# 8.5以后的版本功能比较健全

