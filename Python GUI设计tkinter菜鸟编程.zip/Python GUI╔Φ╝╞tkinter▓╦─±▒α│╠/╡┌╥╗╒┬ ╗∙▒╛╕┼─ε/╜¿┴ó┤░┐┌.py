# import tkinter
# # from tkinter import *
# # root是自定义的名称，一般称为根窗口，可以在此窗口建立许多控件和上层窗口
# root =tkinter.Tk()
# # 放在程序的最后一行，让程序继续执行，同时进入等待与处理窗口事件
# root.mainloop()
# # 有的时候也可以将根窗口称为容器
from tkinter import *
root = Tk()
root.mainloop()

