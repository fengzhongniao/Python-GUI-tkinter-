# # import tkinter
# from tkinter import *
# root = Tk()
# # root.geometry('300×300')窗口设置大小函数使用geometry("width×height+x+y")
# w = 300
# h = 160
# x = 400
# y = 200
# root.title("MyWindow")# 窗口标题
# root.configure(bg='yellow')# 窗口背景颜色
# # root.geometry("300×200+20+20")
# root.iconbitmap("mystar.ico")# 更改图标
# root.mainloop()

from tkinter import *
root = Tk()
screenWidth = root.winfo_screenwidth()
screenHight = root.winfo_screenheight()
w = 300
h = 160
x = (screenWidth - w)/2
y = (screenHight - h)/2
root.geometry("%d×%d+%d+%d" % (w, h, x, y))
root.mainloop()