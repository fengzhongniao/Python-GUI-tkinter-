# 介绍窗口的常用方法
from tkinter import *
root = Tk()
root.title("MyWindow")  # 设置窗口标题，使用字符串
# root.wm_geometry("300*300+1+1")# 设置窗口大小和窗口位置，位置按照平面坐标系，使用的字符串
# root.iconbintmap(""tupian)   更改图标
# root.maxsize(30, 40)  # 拖拽时可以设置窗口最大的宽和高
root.configure(bg='blue')  # 设置窗口的背景颜色
root.mainloop()
