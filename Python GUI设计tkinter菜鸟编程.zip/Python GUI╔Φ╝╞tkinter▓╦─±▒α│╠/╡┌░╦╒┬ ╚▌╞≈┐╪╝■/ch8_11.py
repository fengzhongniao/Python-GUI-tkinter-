# 使用Toplevel窗口仿真对话框
from tkinter import *
import random
root = Tk()
root.title("ch8_11")

msgYes,msgNo,msgExit = 1,2,3
def MessageBox():
    msgType = random.randint(1,3)
    if msgType == msgYes:
        labTxt = 'Yes'
    elif msgType == msgNo:
        labTxt = 'No'
    elif msgType == msgExit:
        labTxt = 'Exit'
    t1 = Toplevel()
    t1.title("Message Box")
    Label(t1,text=labTxt).pack(fill=BOTH,expand=True)
btn = Button(root,text="Click Me",command=MessageBox)
btn.pack()
root.mainloop()