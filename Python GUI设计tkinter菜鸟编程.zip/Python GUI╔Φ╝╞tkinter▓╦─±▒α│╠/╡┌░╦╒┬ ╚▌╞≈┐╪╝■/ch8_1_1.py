# 建立三个不同底色的框架
from tkinter import *
root = Tk()
root.title("ch8_1")

for fm in ["red","green","blue"]:
    Frame(bg=fm,height=50,width=250).pack()
root.mainloop()
