# 将账号和密码字段使用标签框架框起来，此框架标签文字是”数据验证“
from tkinter import *
root = Tk()
root.title("ch8_7")
msg = "欢迎进入Silicon Stone Education系统"
seeGif = PhotoImage(file="sun.gif")
logo = Label(root,image=seeGif,text=msg,compound=BOTTOM)
logo.pack()

# 以下是LabelFrame标签框架
labelFrame = LabelFrame(root,text="数据验证")
accountL = Label(labelFrame,text="Account")
accountL.grid(row=0,column=0)
pwdL = Label(labelFrame,text="Passwoord")
pwdL.grid(row=1,column=0)

accountE = Entry(labelFrame)
accountE.grid(row=0,column=1)
pwdE = Entry(labelFrame,show="*")
pwdE.grid(row=1,column=1,pady=10)
labelFrame.pack(padx=10,pady=5,ipadx=5,ipady=5)
root.mainloop()