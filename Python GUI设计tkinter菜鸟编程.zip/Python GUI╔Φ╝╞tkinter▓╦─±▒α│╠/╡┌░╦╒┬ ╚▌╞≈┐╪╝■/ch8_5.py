# 在含raised属性的框架内创建复选框
from tkinter import *
root = Tk()
root.title("ch8_5")

fm = Frame(width=150,height=80,relief=GROOVE,borderwidth=5)
lab=Label(fm,text="请复选常用的程序语言")
lab.pack()
python = Checkbutton(fm,text="python")
python.pack(anchor=W)
java = Checkbutton(fm,text="java")
java.pack(anchor=W)
ruby = Checkbutton(fm,text="Ruby")
ruby.pack(anchor=W)
fm.pack(padx=10,pady=10)
root.mainloop()