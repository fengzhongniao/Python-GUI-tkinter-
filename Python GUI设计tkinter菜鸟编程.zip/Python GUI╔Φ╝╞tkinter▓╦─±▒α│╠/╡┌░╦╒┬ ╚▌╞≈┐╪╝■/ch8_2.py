"""
横向配置方式(side=LEFT),同时让鼠标光标在不同框架上有不同形状
"""
from tkinter import *

root = Tk()
root.title("ch8_2")

fms = {'red':'cross','green':'boat','blue':'clock'}
for fmColor in fms:
    Frame(root,bg=fmColor,cursor=fms[fmColor],
          height=50,width=200).pack(side=LEFT)

root.mainloop()