# 设置Toplevel窗口的标题和大小
from tkinter import *
root = Tk()
root.title("ch8_10")

t1 = Toplevel()
t1.title("Toplevel")
Label(t1,text="I am a Toplevel").pack()
root.mainloop()