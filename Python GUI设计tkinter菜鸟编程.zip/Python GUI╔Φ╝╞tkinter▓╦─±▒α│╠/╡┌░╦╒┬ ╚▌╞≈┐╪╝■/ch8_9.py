# 建立一个Toplevel窗口，为了区分在Toplevel窗口中增加字符串
from tkinter import *
root = Tk()
root.title("ch8_9")
t1 = Toplevel()
t1.title('niaho')
Label(t1,text="I am a Toplevel").pack()

root.mainloop()