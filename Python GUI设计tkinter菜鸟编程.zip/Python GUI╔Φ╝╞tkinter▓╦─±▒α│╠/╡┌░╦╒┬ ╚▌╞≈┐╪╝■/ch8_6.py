# 额外对relief属性的支持
from tkinter import *
from tkinter.ttk import Frame,Style
root = Tk()
root.title("ch8_6")
style = Style()
style.theme_use("alt")

fam1 = Frame(root,width=150,height=80,relief="flat")
fam1.grid(row=0,column=0,padx=5,pady=5)
fam2 = Frame(root,width=150,height=80,relief="groove")
fam2.grid(row=0,column=1,padx=5,pady=5)
fam3 = Frame(root,width=150,height=80,relief="raised")
fam3.grid(row=0,column=2,padx=5,pady=5)
fam4 = Frame(root,width=150,height=80,relief="ridge")
fam4.grid(row=1,column=0,padx=5,pady=5)
fam5 = Frame(root,width=150,height=80,relief="solid")
fam5.grid(row=1,column=1,padx=5,pady=5)
fam5 = Frame(root,width=150,height=80,relief="sunken")
fam5.grid(row=1,column=2,padx=5,pady=5)
root.mainloop()


